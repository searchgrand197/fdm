from django.shortcuts import render, redirect
import requests
from django.conf import settings
from .models import MenuItem, Category,Customer,TakeAwayCoupons,Coupons,FlashOffer,ScrollingText,DeliveryCharge,Loading,WebsiteItems,WebsiteOrder,UserCoupon,DineinCoupons,Topping
import razorpay
import json
from django.http import HttpResponse, JsonResponse
from django.contrib.sites.shortcuts import get_current_site
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import authenticate, login,logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from django.core.serializers import serialize
from django.shortcuts import render, get_object_or_404, redirect
from .models import Shop
from django.utils import timezone

client = razorpay.Client(auth=(settings.RAZORPAY_API_KEY, settings.RAZORPAY_API_SECRET))
@csrf_exempt
def initiate_payment(request):
    amount = int(request.POST.get('amount', 0))
    data = {
        'amount': amount * 100,  # Razorpay expects amount in paise (e.g., 100 INR = 10000 paise)
        'currency': 'INR',
        'payment_capture': '1'  # Auto capture the payment after successful authorization
    }
    response = client.order.create(data=data)
    return JsonResponse({'id': response['id']})



def payment_view(request):
    amount = 10  # Set the amount dynamically or based on your requirements
    order_id = initiate_payment(amount)
    context = {
        'order_id': order_id,
        'amount': amount
    }
    return render(request, 'payment.html', context)
def payment_success_view(request):
    if request.method == 'POST':
        order_id = request.POST.get('order_id')
        payment_id = request.POST.get('razorpay_payment_id')
        signature = request.POST.get('razorpay_signature')
        params_dict = {
            'razorpay_order_id': order_id,
            'razorpay_payment_id': payment_id,
            'razorpay_signature': signature
        }
        print(params_dict)
        try:
            client.utility.verify_payment_signature(params_dict)
            # Payment signature verification successful
            # Perform any required actions (e.g., update the order status)
            return render(request, 'payment_success.html')
        except razorpay.errors.SignatureVerificationError as e:
            # Payment signature verification failed
            # Handle the error accordingly
            return render(request, 'payment_failure.html')
    return HttpResponse("hi")

def menu(request):
    try:
        if request.user.is_authenticated:
            user = request.user
            used_coupons = UserCoupon.objects.filter(user=user, used=True)
            customer = Customer.objects.get(user=request.user)
            print("authorized")
            if used_coupons.exists():
                used_coupon_ids = used_coupons.values_list('coupon__id', flat=True)
                for_one_time_coupons = Coupons.objects.filter(id__in=used_coupon_ids, for_one_time=True)
                coupons = Coupons.objects.exclude(id__in=used_coupon_ids)
                print(coupons)
            else:
                # No used coupons found for the user
                coupons = Coupons.objects.all()
            try:
                flash_offers = FlashOffer.objects.get(visibility=True)
            except:
                flash_offers="flash_offers"
                pass
            selected_category_ids = MenuItem.objects.values_list('category__id', flat=True).distinct()
            selected_categories = Category.objects.filter(id__in=selected_category_ids)
            texts = ScrollingText.objects.all()
            takeaway=TakeAwayCoupons.objects.all()
            delivery_charge = DeliveryCharge.objects.first()  # Assuming there's only one delivery charge instance
            # categories = Category.objects.all()
            menu_items = MenuItem.objects.all()
            return render(request,'index.html', {'categories': selected_categories, 'menu_items': menu_items,'customer': customer,'coupons':coupons,'flash_offer': flash_offers,'movingtext':texts,'delivery':delivery_charge,'takeaway':takeaway})
        else:
            gif = Loading.objects.first()
            print(gif)
            return render(request,"login_firebase.html",{'gif': gif})
    except:
        gif = Loading.objects.first()
        return render(request,"login_firebase.html",{'gif': gif})


@csrf_exempt
def firebase_login_save(request):
    data = json.loads(request.body)
    # Extract the required parameters
    username = data.get('username')
    provider = data.get('provider')
    token = data.get('token')
    print(username)
    print(provider)
    print(token)
    user = authenticate(request,username=username,password='12121212')
    print(user)
    print("I am here")

    if user is not None:
        print("authorized")
        login(request, user)
        return render(request,"index.html")


    else:
        # User doesn't exist, create a new one
        user = User.objects.create_user(username=username, password='12121212')
        customer = Customer.objects.create(user=user, name='', address='', phone='')
        login(request, user)
        print("else")

    return render(request,"index.html")
def logout_view(request):
    logout(request)
    # Redirect to a page after logout (you can customize this URL)
    return render(request,'login_firebase.html')

from .forms import CustomerForm

@login_required
def edit_customer(request):
    customer = request.user.customer

    if request.method == 'POST':
        form = CustomerForm(request.POST, instance=customer)
        if form.is_valid():
            form.save()
            messages.success(request, 'Your profile has been updated successfully.')
            return menu(request)
    else:
        form = CustomerForm(instance=customer)

    return render(request, 'edit_customer.html', {'form': form})
@csrf_exempt
def save_order(request):
    if request.method == 'POST':
        data = request.POST.get('data')
        order_data = json.loads(data)
        coupon = order_data.get('coupon')
        print(coupon)
        if (coupon !="Null"):
            try:
                coufromcou = Coupons.objects.get(coupon_name=coupon,for_one_time='True')
                UserCoupon.objects.create(user= request.user,coupon=coufromcou,used='True')
            except:
                pass
        name = order_data.get('name')
        address = order_data.get('address')
        phone=order_data.get('phone')
        total=order_data.get('total')
        items = order_data.get('items', [])
        print(items)
        order = WebsiteOrder.objects.create(
            user=request.user,  # Assuming there's a logged-in user
            name=name,
            phone=phone,
            address=address,
            total=total,
            order_status=1,  # Set the initial order status as 'In', adjust as needed
        )

        # Create WebsiteItems instances related to the saved WebsiteOrder
        for item_data in order_data['items']:
            WebsiteItems.objects.create(
                order_link=order,
                name=item_data['name'],
                price=item_data['price'],
                quantity=item_data.get('quantity', 1)  # Get quantity from item_data, default to 1 if not provided
            )
        return JsonResponse({'status': 'success', 'message': 'Order saved successfully', 'order_id': order.invoice})

@csrf_exempt
def get_all_website_orders(request):
    return render(request, 'order.html')
def status(request):
    shop = get_object_or_404(Shop, id=2)
    if(shop.status==True):
        return render(request, 'open.html',{'shop': shop})
    else:
        return render(request, 'close.html',{'shop': shop})

def open_shop(request):
    shop = get_object_or_404(Shop, id=2)  # Assuming there's only one shop instance
    shop.status = True
    shop.save()
    menuitems = MenuItem.objects.all()
    for item in menuitems:
        item.available = True
        item.save()
    return render(request, 'open.html', {'shop': shop})

def close_shop(request):
    shop = get_object_or_404(Shop, id=2)  # Assuming there's only one shop instance
    shop.status = False
    shop.save()
    menuitems = MenuItem.objects.all()
    for item in menuitems:
        item.available = False
        item.save()
    return render(request, 'close.html', {'shop': shop})

def menu_view(request, table_number):
    try:
        flash_offers = FlashOffer.objects.get(visibility=True)
    except:
        flash_offers="flash_offers"
        pass
    selected_category_ids = MenuItem.objects.values_list('category__id', flat=True).distinct()
    selected_categories = Category.objects.filter(id__in=selected_category_ids)
    texts = ScrollingText.objects.all()
    takeaway=DineinCoupons.objects.all()
    table_number=table_number
    delivery_charge =0 # Assuming there's only one delivery charge instance
    # categories = Category.objects.all()
    menu_items = MenuItem.objects.all()
    return render(request,'index2.html', {'delivery':delivery_charge, 'table_number':table_number,'categories': selected_categories, 'menu_items': menu_items,'flash_offer': flash_offers,'movingtext':texts,'takeaway':takeaway})
    # return render(request,'index.html', {'categories': selected_categories, 'menu_items': menu_items,'customer': customer,'coupons':coupons,'flash_offer': flash_offers,'movingtext':texts,'delivery':delivery_charge,'takeaway':takeaway})

@csrf_exempt
def submit_order_rating(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            order_id = data.get('order_id')
            rating = data.get('rating')
            comment = data.get('comment')
            item_ratings = data.get('item_ratings', {})

            if not isinstance(rating, (int, float)) or rating < 1 or rating > 5:
                return JsonResponse({
                    'status': 'error',
                    'message': 'Invalid rating value. Must be between 1 and 5'
                }, status=400)

            order = WebsiteOrder.objects.get(invoice=order_id, user=request.user)
            
            # Only proceed if the order hasn't been rated yet
            if order.rating is None:
                order.rating = rating
                order.comment = comment
                order.rated_at = timezone.now()
                order.save()

                # Get all items in this order and update their ratings
                order_items = WebsiteItems.objects.filter(order_link=order)
                for order_item in order_items:
                    try:
                        # Extract base item name (remove toppings in parentheses)
                        base_item_name = order_item.name.split('(')[0].strip()
                        menu_item = MenuItem.objects.get(name=base_item_name)
                        
                        # Use item-specific rating if provided, otherwise use overall rating
                        item_rating = float(item_ratings.get(str(order_item.id), rating))
                        if 1 <= item_rating <= 5:  # Validate individual item rating
                            menu_item.update_rating(item_rating)
                    except (MenuItem.DoesNotExist, ValueError) as e:
                        print(f"Error updating rating for {order_item.name}: {str(e)}")
                        continue

                return JsonResponse({
                    'status': 'success',
                    'message': 'Rating submitted successfully'
                })
            else:
                return JsonResponse({
                    'status': 'error',
                    'message': 'Order has already been rated'
                }, status=400)
        except WebsiteOrder.DoesNotExist:
            return JsonResponse({
                'status': 'error',
                'message': 'Order not found'
            }, status=404)
        except ValueError as e:
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=400)
        except Exception as e:
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'}, status=405)

# testing program for ayush to check data with get api
@login_required
def myorder(request):
    try:
        # Get all orders for the current user, ordered by invoice number (most recent first)
        orders = WebsiteOrder.objects.filter(user=request.user).order_by('-invoice')
        
        # Format orders for template
        formatted_orders = []
        for order in orders:
            # Get all items for this order
            items = WebsiteItems.objects.filter(order_link=order)
            
            # Format order data
            order_dict = {
                'invoice': order.invoice,
                'time': {'value': order.created_at},  # Use the order's actual creation time
                'total': order.total,
                'orderstatus': order.order_status,
                'rating': order.rating,
                'comment': order.comment,
                'items': []
            }
            
            # Add items to order
            for item in items:
                order_dict['items'].append({
                    'name': item.name,
                    'quantity': item.quantity,
                    'price': item.price,
                })
            
            formatted_orders.append(order_dict)

        return render(request, 'myorder.html', {'order_data': formatted_orders})
    except Exception as e:
        print(f"Error in myorder view: {str(e)}")  # For debugging
        messages.error(request, "There was an error retrieving your orders.")
        return render(request, 'myorder.html', {'order_data': []})

def get_toppings(request, menu_item_id):
    """Get available toppings for a menu item"""
    try:
        menu_item = MenuItem.objects.get(id=menu_item_id)
        toppings = menu_item.toppings.filter(available=True).values('id', 'name', 'price', 'available')
        return JsonResponse(list(toppings), safe=False)
    except MenuItem.DoesNotExist:
        return JsonResponse({'error': 'Menu item not found'}, status=404)