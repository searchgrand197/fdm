from django.urls import path
from .views import (
    menu_view, get_all_website_orders, get_toppings, submit_order_rating,
    firebase_login_save, logout_view, edit_customer, save_order,
    status, myorder, menu, payment_view, payment_success_view,
    initiate_payment, open_shop, close_shop
)
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('', menu, name='menu'),
    path('payment/', payment_view, name='payment'),
    path('payment/success/', payment_success_view, name='payment_success'),
    path('initiate_payment/', initiate_payment, name='initiate_payment'),
    path('firebase_login_save/', firebase_login_save, name='firebase_login_save'),
    path('logout/', logout_view, name='logout'),
    path('edit_customer/', edit_customer, name='edit_customer'),
    path('save_order/', save_order, name='save_order'),
    path('myorder/', myorder, name='myorder'),
    path('orders/', get_all_website_orders, name='get_all_website_orders'),
    path('get-toppings/<int:menu_item_id>/', get_toppings, name='get_toppings'),
    path('submit_order_rating/', submit_order_rating, name='submit_order_rating'),
    path('open_shop/', open_shop, name='open_shop'),
    path('close_shop/', close_shop, name='close_shop'),
    path('status/', status, name='status'),
    path('<int:table_number>/', menu_view, name='menu_view'),
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)